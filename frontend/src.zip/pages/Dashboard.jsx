import "../layouts/AppLayout.css";
import "./Dashboard.css";

import {
  Lightbulb,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  TrendingUp,
  TrendingDown,
  ArrowRight,
} from "lucide-react";

/* =========================
   Summary Cards Data
========================= */

const summaryCards = [
  {
    title: "Total Balance",
    value: "₹24,562.00",
    change: "+2.4% vs last month",
    icon: Wallet,
    positive: true,
  },
  {
    title: "Total Income",
    value: "₹8,450.00",
    change: "+1.1% vs last month",
    icon: ArrowDownRight,
    positive: true,
  },
  {
    title: "Total Expenses",
    value: "₹3,240.50",
    change: "+5.2% vs last month",
    icon: ArrowUpRight,
    positive: false,
  },
];

/* =========================
   Transactions Data
========================= */

const transactions = [
  {
    title: "Domino's Pizza",
    category: "Food",
    date: "Today, 8:42 PM",
    amount: "-₹18.50",
    income: false,
  },
  {
    title: "Uber",
    category: "Transport",
    date: "Today, 6:20 PM",
    amount: "-₹12.40",
    income: false,
  },
  {
    title: "Netflix",
    category: "Entertainment",
    date: "Yesterday",
    amount: "-₹15.99",
    income: false,
  },
  {
    title: "Salary",
    category: "Income",
    date: "Aug 20, 2026",
    amount: "+₹4,250.00",
    income: true,
  },
];

/* =========================
   Summary Card Component
========================= */

function SummaryCard({ card }) {
  const Icon = card.icon;

  return (
    <div className="summary-card glass-card">
      <div className="summary-header">
        <span>{card.title}</span>

        <Icon size={20} />
      </div>

      <div className="summary-value">
        {card.value}
      </div>

      <div
        className={`summary-change ${
          card.positive ? "positive" : "negative"
        }`}
      >
        {card.positive ? (
          <TrendingUp size={15} />
        ) : (
          <TrendingDown size={15} />
        )}

        <span>{card.change}</span>
      </div>
    </div>
  );
}

/* =========================
   Transaction Component
========================= */

function Transaction({ transaction }) {
  return (
    <div className="transaction">

      <div
        className={`transaction-icon ${
          transaction.income ? "income" : "expense"
        }`}
      >
        {transaction.income ? (
          <ArrowDownRight size={18} />
        ) : (
          <ArrowUpRight size={18} />
        )}
      </div>

      <div className="transaction-info">

        <div className="transaction-title">
          {transaction.title}
        </div>

        <div className="transaction-meta">
          <span>{transaction.category}</span>

          <span>•</span>

          <span>{transaction.date}</span>
        </div>

      </div>

      <div
        className={`transaction-amount ${
          transaction.income ? "income" : "expense"
        }`}
      >
        {transaction.amount}
      </div>

    </div>
  );
}

/* =========================
   Budget Item Component
========================= */

function BudgetItem({
  name,
  amount,
  limit,
  percentage,
}) {
  return (
    <div className="budget-item">

      <div className="budget-top">

        <span>{name}</span>

        <span>
          {amount} <small>of {limit}</small>
        </span>

      </div>

      <div className="progress-track">

        <div
          className="progress-value"
          style={{
            width: `${percentage}%`,
          }}
        />

      </div>

    </div>
  );
}

/* =========================
   Dashboard Component
========================= */

export default function Dashboard() {
  return (
    <div className="dashboard">

      {/* =========================
          Page Heading
      ========================= */}

      <div className="page-heading">

        <div>

          <p className="eyebrow">
            OVERVIEW
          </p>

          <h1>
            Good evening, Ashu
          </h1>

          <p className="page-subtitle">
            Here's what's happening with your money.
          </p>

        </div>

        <button className="period-button">
          August 2026
        </button>

      </div>

      {/* =========================
          AI Insight
      ========================= */}

      <section className="ai-insight">

        <div className="ai-icon">
          <Lightbulb size={20} />
        </div>

        <div className="ai-content">

          <h3>
            AI Insight

            <span className="pulse-dot" />
          </h3>

          <p>
            You could save $50 this week by reducing
            dining out based on your recent spending trend.
          </p>

        </div>

        <ArrowRight
          className="ai-arrow"
          size={20}
        />

      </section>

      {/* =========================
          Summary Cards
      ========================= */}

      <section className="summary-grid">

        {summaryCards.map((card) => (
          <SummaryCard
            key={card.title}
            card={card}
          />
        ))}

      </section>

      {/* =========================
          Dashboard Grid
      ========================= */}

      <section className="dashboard-grid">

        {/* =========================
            Income vs Expenses Chart
        ========================= */}

        <div className="chart-card glass-card">

          <div className="section-heading">

            <div>

              <p className="eyebrow">
                MONTHLY OVERVIEW
              </p>

              <h2>
                Income vs Expenses
              </h2>

            </div>

            <select defaultValue="4weeks">

              <option value="4weeks">
                Last 4 weeks
              </option>

              <option value="6months">
                Last 6 months
              </option>

            </select>

          </div>

          <div className="chart">

            <div className="chart-grid">

              <span>₹8k</span>
              <span>₹6k</span>
              <span>₹4k</span>
              <span>₹2k</span>
              <span>₹0</span>

            </div>

            <div className="bars">

              {[60, 75, 85, 82].map(
                (income, index) => (
                  <div
                    className="bar-group"
                    key={index}
                  >

                    <div
                      className="bar income-bar"
                      style={{
                        height: `${income}%`,
                      }}
                    />

                    <div
                      className="bar expense-bar"
                      style={{
                        height: `${
                          [40, 80, 50, 57][index]
                        }%`,
                      }}
                    />

                  </div>
                )
              )}

            </div>

            <div className="chart-labels">

              <span>W1</span>
              <span>W2</span>
              <span>W3</span>
              <span>W4</span>

            </div>

          </div>

          <div className="legend">

            <span>
              <i className="income-dot" />
              Income
            </span>

            <span>
              <i className="expense-dot" />
              Expenses
            </span>

          </div>

        </div>

        {/* =========================
            Budget Breakdown
        ========================= */}

        <div className="budget-card glass-card">

          <div className="section-heading">

            <div>

              <p className="eyebrow">
                THIS MONTH
              </p>

              <h2>
                Budget Breakdown
              </h2>

            </div>

          </div>

          <BudgetItem
            name="Food"
            amount="₹420"
            limit="₹500"
            percentage={84}
          />

          <BudgetItem
            name="Transport"
            amount="₹180"
            limit="₹300"
            percentage={60}
          />

          <BudgetItem
            name="Shopping"
            amount="₹320"
            limit="₹500"
            percentage={64}
          />

          <BudgetItem
            name="Entertainment"
            amount="₹120"
            limit="₹250"
            percentage={48}
          />

        </div>

      </section>

      {/* =========================
          Recent Transactions
      ========================= */}

      <section className="transactions-card glass-card">

        <div className="section-heading">

          <div>

            <p className="eyebrow">
              ACTIVITY
            </p>

            <h2>
              Recent Transactions
            </h2>

          </div>

          <button className="view-all">
            <span>View all</span>
            <ArrowRight size={16} />
          </button>

        </div>

        <div className="transaction-list">

          {transactions.map((transaction) => (
            <Transaction
              key={`${transaction.title}-${transaction.date}`}
              transaction={transaction}
            />
          ))}

        </div>

      </section>

    </div>
  );
}