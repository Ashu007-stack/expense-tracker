import { NavLink, Outlet } from "react-router-dom";
import {
  LayoutDashboard,
  Receipt,
  BarChart3,
  FolderKanban,
  User,
  Plus,
} from "lucide-react";

import logo from "../assets/logo.png";
import "./AppLayout.css";


const navigation = [
  {
    name: "Dashboard",
    path: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    name: "Expenses",
    path: "/expenses",
    icon: Receipt,
  },
  {
    name: "Analytics",
    path: "/analytics",
    icon: BarChart3,
  },
  {
    name: "Categories",
    path: "/categories",
    icon: FolderKanban,
  },
  {
    name: "Profile",
    path: "/profile",
    icon: User,
  },
];


function NavigationItem({ item }) {
  const Icon = item.icon;

  return (
    <NavLink
      to={item.path}
      className={({ isActive }) =>
        `navigation-item ${isActive ? "active" : ""}`
      }
    >
      <Icon size={20} strokeWidth={1.8} />

      <span>{item.name}</span>
    </NavLink>
  );
}


export default function AppLayout() {
  return (
    <div className="app-shell">

      {/* =========================
          TOP BAR
      ========================= */}

      <header className="topbar">

        <div className="brand">

          <img
            src={logo}
            alt="Expense Tracker"
            className="brand-logo"
          />

          <span>Expense Tracker</span>

        </div>


        <div className="topbar-user">

          <div className="user-avatar">
            U
          </div>

        </div>

      </header>


      {/* =========================
          DESKTOP / TABLET SIDEBAR
      ========================= */}

      <aside className="sidebar">

        <nav className="sidebar-navigation">

          {navigation.map((item) => (
            <NavigationItem
              key={item.path}
              item={item}
            />
          ))}

        </nav>


        <NavLink
          to="/expenses/add"
          className="sidebar-add"
        >
          <Plus size={19} />

          <span>Add Expense</span>
        </NavLink>

      </aside>


      {/* =========================
          MAIN CONTENT
      ========================= */}

      <main className="main-content">
        <Outlet />
      </main>


      {/* =========================
          MOBILE ADD BUTTON
      ========================= */}

      <NavLink
        to="/expenses/add"
        className="floating-add"
        aria-label="Add Expense"
      >
        <Plus size={25} />
      </NavLink>


      {/* =========================
          MOBILE BOTTOM NAVIGATION
      ========================= */}

      <nav className="mobile-navigation">

        {navigation.map((item) => (
          <NavigationItem
            key={item.path}
            item={item}
          />
        ))}

      </nav>

    </div>
  );
}